import pygame, sys, Background, Platform, Player, Monster
from pygame.locals import *

def main():
    """The main game function that contains all the game attributes and the
        main game loop.
    """
    pygame.init()
    FPS = 30
    fps_clock = pygame.time.Clock()
    
    SCREENSIZE = (800, 600)
    
    screen = pygame.display.set_mode(SCREENSIZE)
    pygame.display.set_caption("Journey to the West")
    
    pygame.mouse.set_visible(False)
    
    background = Background.Background((800, 600))
    platform = Platform.platformGroup()
    player = Player.Player((-100, 0))
    
    moveL = False
    moveR = False
    
    gameIdle =True
    gameContinue = True
    gamePause = False
    
    GAME_OVER = USEREVENT + 1
    pygame.time.set_timer(GAME_OVER, 10000)
    
    pygame.mixer.music.load('bg.ogg')
    pygame.mixer.music.set_endevent(USEREVENT)
    pygame.mixer.music.play()
    
    fullscreen = False
    
    while True:
        if gameIdle:
            player.hideHeart()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                if event.type == KEYDOWN:
                    if event.key == K_RETURN:
                        mods = pygame.key.get_mods()
                        if mods & KMOD_ALT:
                            if fullscreen:
                                fullscreen = False
                                screen = pygame.display.set_mode(SCREENSIZE)
                            else:
                                fullscreen = True
                                screen = pygame.display.set_mode(SCREENSIZE,
                                                             FULLSCREEN)
                        else:
                            gameIdle = False
                            player.unhideHeart()
                if event.type == USEREVENT:
                    pygame.mixer.music.play()
            player.land(platform.platList(), Platform.Platform(1, (13000, 3)))
            background.update(screen)
            demo(screen)
            player.update(screen)
            platform.update(screen)
            if not player.moveR():
                    background.moveR()
        elif gameContinue:
            if gamePause:
                pause(screen)
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == KEYDOWN:
                        if event.key == K_RETURN:
                            mods = pygame.key.get_mods()
                            if mods & KMOD_ALT:
                                if fullscreen:
                                    fullscreen = False
                                    screen = pygame.display.set_mode(SCREENSIZE)
                                else:
                                    fullscreen = True
                                    screen = pygame.display.set_mode(SCREENSIZE,
                                                                 FULLSCREEN)
                        if event.key == K_p:
                            gamePause = False
                        if event.key == K_q:
                            pygame.quit()
                            sys.exit()
                    if event.type == USEREVENT:
                        pygame.mixer.music.play()
            else:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                    if event.type == KEYDOWN:
                        if event.key == K_EQUALS:
                            player._life += 1
                        if event.key == K_RETURN:
                            mods = pygame.key.get_mods()
                            if mods & KMOD_ALT:
                                if fullscreen:
                                    fullscreen = False
                                    screen = pygame.display.set_mode(SCREENSIZE)
                                else:
                                    fullscreen = True
                                    screen = pygame.display.set_mode(SCREENSIZE,
                                                                 FULLSCREEN)
                        if event.key == K_RIGHT:
                            moveR = True
                        if event.key == K_LEFT:
                            moveL = True
                        if event.key == K_SPACE:
                            player.jump()
                        if event.key == K_p:
                            gamePause = True
                    if event.type == KEYUP:
                        if event.key == K_RIGHT:
                            moveR = False
                        if event.key == K_LEFT:
                            moveL = False
                    if event.type == USEREVENT:
                        pygame.mixer.music.play()
                if moveL:
                    player.moveL()
                if moveR:
                    if not player.moveR():
                        background.moveR()
                        platform.moveR()
                        screen.fill((0, 0, 0))
                player.land(platform.platList(), platform.finalPlat())
                player.enemyCollision(platform.monList())
                player.fruitCollison(platform.fruList())
                player.fireballCollison(platform.fireList())
                if player.gameOver() or player.win():
                    gameContinue = False
                background.update(screen)
                platform.update(screen)
                player.update(screen)
        else:
            if player.win():
                gameWon(screen)
            else:
                gameOver(screen)
            for event in pygame.event.get():
                if event.type == KEYDOWN:
                    if event.key == K_RETURN:
                        mods = pygame.key.get_mods()
                        if mods & KMOD_ALT:
                            if fullscreen:
                                fullscreen = False
                                screen = pygame.display.set_mode(SCREENSIZE)
                            else:
                                fullscreen = True
                                screen = pygame.display.set_mode(SCREENSIZE,
                                                             FULLSCREEN)
                    if event.key == K_r:
                        background = Background.Background((800, 600))
                        platform = Platform.platformGroup()
                        player = Player.Player((150, 200))
                        gameContinue = True
                        moveL = False
                        moveR = False
                if event.type == GAME_OVER:
                    gameIdle = True
                    background = Background.Background((800, 600))
                    platform = Platform.platformGroup()
                    player = Player.Player((150, 200))
                    gameContinue = True
                    moveL = False
                    moveR = False
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == USEREVENT:
                    pygame.mixer.music.play()
        pygame.display.update()
        fps_clock.tick(FPS)
    
def demo(target):
    """Displays the starting screen of the game.
    
    Args:
        target(pygame.Surface): The surface to draw starting screen onto.
    """
    font1 = pygame.font.SysFont('Chinese Takeaway', 70, 5, False)
    font2 = pygame.font.SysFont('Chinese Takeaway', 20, 5, False)
    label1 = pygame.image.load('jtw.png')
    label2 = font2.render('Press <- or -> to move, space to jump', True, (125, 125, 125))
    label3 = font2.render('Press ENTER to start', True, (0, 0, 255))
    target.blit(label1, (80, 150))
    target.blit(label2, (100, 350))
    target.blit(label3, (100, 380))
    
def pause(target):
    """Displays the pause screen of the game.
    
    Args:
        target(pygame.Surface): The surface to draw pause screen onto.
    """
    font1 = pygame.font.SysFont('Chinese Takeaway', 40, 5, False)
    font2 = pygame.font.SysFont('Chinese Takeaway', 20, 5, False)
    label = font1.render('GAME PAUSED', True, (0, 255, 0))
    label2 = font2.render('Press P to resume', True, (0, 0, 255))
    label3 = font2.render('Press Q to quit', True, (0, 0, 255))
    target.blit(label, (100, 300))
    target.blit(label2, (100, 350))
    target.blit(label3, (100, 375))

def gameOver(target):
    """Displays the gameOver screen of the game.
    
    Args:
        target(pygame.Surface): The surface to draw gameOver screen onto.
    """
    font1 = pygame.font.SysFont('Chinese Takeaway', 40, 5, False)
    font2 = pygame.font.SysFont('Chinese Takeaway', 20, 5, False)
    label = font1.render('GAME OVER', True, (0, 255, 0))
    label2 = font2.render('Press R to restart', True, (0, 0, 255))
    target.blit(label, (100, 300))
    target.blit(label2, (100, 350))
    
def gameWon(target):
    """Displays the winning screen of the game.
    
    Args:
        target(pygame.Surface): The surface to draw winning screen onto.
    """
    font1 = pygame.font.SysFont('Chinese Takeaway', 40, 5, False)
    font2 = pygame.font.SysFont('Chinese Takeaway', 20, 5, False)
    label = font1.render('YOU WIN', True, (0, 255, 0))
    label2 = font2.render('Press R to restart', True, (0, 0, 255))
    target.blit(label, (100, 300))
    target.blit(label2, (100, 350))

if __name__ == '__main__':
    main()
